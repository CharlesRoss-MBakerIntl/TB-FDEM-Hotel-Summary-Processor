# Expired Certificates and Configuration for Testing

This has a valid certificate authority in [ca](./ca) and an invalid server
certificate in [server](./server).

This can all be regenerated with:

```
make clean
make all
```
