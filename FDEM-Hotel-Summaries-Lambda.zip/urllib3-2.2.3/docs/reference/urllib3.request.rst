urllib3.request()
=================

.. autofunction:: urllib3.request
